import { beforeEach, describe, expect, it } from 'vitest';
import { BACKUP_SCHEMA_VERSION, applyBackup, buildBackup, parseBackup } from './backup';
import { KEYS, loadRoutes, loadTrip, loadVisits, saveRoutes, saveTrip, saveVisits } from './storage';
import { DEFAULT_ROUTE_DRAFT, loadRouteDraft, saveRouteDraft } from './routeDraft';
import type { SavedRoute, TripState, VisitMap } from '../types';

class MemoryStorage implements Storage {
  private m = new Map<string, string>();
  get length() {
    return this.m.size;
  }
  clear() {
    this.m.clear();
  }
  getItem(k: string) {
    return this.m.has(k) ? this.m.get(k)! : null;
  }
  key(i: number) {
    return [...this.m.keys()][i] ?? null;
  }
  removeItem(k: string) {
    this.m.delete(k);
  }
  setItem(k: string, v: string) {
    this.m.set(k, v);
  }
}

beforeEach(() => {
  (globalThis as { localStorage?: Storage }).localStorage = new MemoryStorage();
});

const rec = (state: VisitMap[string]['state'], at: string): VisitMap[string] => ({
  state,
  visitedAt: state === 'visited' || state === 'stamped' ? at : null,
  wishlistAt: state === 'wishlist' ? at : null,
  stampAt: state === 'stamped' ? at : null,
  updatedAt: at,
});

const sampleVisits: VisitMap = {
  'mne-00001': rec('visited', '2026-08-01T00:00:00.000Z'),
  'mne-00002': rec('stamped', '2026-08-02T00:00:00.000Z'),
};

const sampleRoute: SavedRoute = {
  id: 'r-1',
  name: 'テストコース',
  createdAt: '2026-08-10T00:00:00.000Z',
  route: { stops: [], legs: [] },
  done: false,
} as unknown as SavedRoute;

describe('バックアップの書き出し', () => {
  it('現在の記録・設定を含むJSONを組み立てる', () => {
    saveVisits(sampleVisits);
    const b = buildBackup();
    expect(b.schemaVersion).toBe(BACKUP_SCHEMA_VERSION);
    expect(typeof b.exportedAt).toBe('string');
    expect(b.visits).toEqual(sampleVisits);
    expect(Array.isArray(b.routes)).toBe(true);
    expect(b.settings.map.markerMode).toBe('all');
  });
  it('書き出し→パースで往復できる', () => {
    saveVisits(sampleVisits);
    const text = JSON.stringify(buildBackup());
    const r = parseBackup(text);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.visits).toEqual(sampleVisits);
  });
});

describe('バックアップの検証', () => {
  it('壊れたJSONはエラーになる（記録は変更しない）', () => {
    saveVisits(sampleVisits);
    const r = parseBackup('{bad json');
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toContain('JSON');
    expect(loadVisits()).toEqual(sampleVisits);
  });
  it('配列やnullはバックアップ形式として拒否する', () => {
    expect(parseBackup('[]').ok).toBe(false);
    expect(parseBackup('null').ok).toBe(false);
    expect(parseBackup('"text"').ok).toBe(false);
  });
  it('未来のschemaVersionは拒否する', () => {
    const r = parseBackup(JSON.stringify({ schemaVersion: BACKUP_SCHEMA_VERSION + 1, visits: {} }));
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toContain('バージョン');
  });
  it('visits内の1件だけが不正な場合、そのレコードだけを除外し復元全体は拒否しない（Astra監査P1）', () => {
    const r = parseBackup(
      JSON.stringify({
        schemaVersion: 1,
        visits: { 'mne-1': { state: '謎の状態' }, ...sampleVisits },
      }),
    );
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.data.visits['mne-1']).toBeUndefined(); // 不正な1件だけ除外される
      expect(r.data.visits).toEqual(sampleVisits); // 他の正常な記録は残る
    }
  });

  it('visitsフィールド自体が根本的に不正な形（配列等）なら拒否する', () => {
    const r = parseBackup(JSON.stringify({ schemaVersion: 1, visits: ['not', 'an', 'object'] }));
    expect(r.ok).toBe(false);
  });

  it('routes内の1件だけが不正(legs欠落等)な場合、そのルートだけを除外し復元全体は拒否しない（Astra監査P1）', () => {
    const brokenRoute = { id: 'r-broken', name: '壊れたコース', createdAt: '2026-08-10T00:00:00.000Z', route: { stops: [] }, done: false };
    const r = parseBackup(
      JSON.stringify({ schemaVersion: 1, visits: {}, routes: [sampleRoute, brokenRoute], trip: null }),
    );
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.data.routes.map((x) => x.id)).toEqual(['r-1']); // 壊れたルートだけ除外される
    }
  });
  it('settings欠落時は初期値で補完する', () => {
    const r = parseBackup(JSON.stringify({ schemaVersion: 1, visits: sampleVisits }));
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.settings.map).toEqual({ markerMode: 'all', labelMode: 'auto' });
  });
});

describe('復元の適用', () => {
  const backupText = () =>
    JSON.stringify({
      schemaVersion: 1,
      appVersion: '1.0.0',
      exportedAt: '2026-08-20T00:00:00.000Z',
      visits: sampleVisits,
      routes: [sampleRoute],
      trip: null,
      settings: { map: { markerMode: 'cluster', labelMode: 'always' } },
    });

  it('上書き: 既存の記録を置き換える', () => {
    saveVisits({ 'mne-99999': rec('wishlist', '2026-07-01T00:00:00.000Z') });
    const r = parseBackup(backupText());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const applied = applyBackup(r.data, 'overwrite');
    expect(applied.visits).toEqual(sampleVisits);
    expect(loadVisits()).toEqual(sampleVisits);
    expect(loadVisits()['mne-99999']).toBeUndefined();
    expect(loadRoutes().map((x) => x.id)).toEqual(['r-1']);
  });

  it('統合: 既存に無い記録を追加しつつバックアップ側を優先する', () => {
    saveVisits({
      'mne-99999': rec('wishlist', '2026-07-01T00:00:00.000Z'),
      'mne-00001': rec('unvisited', '2026-07-02T00:00:00.000Z'),
    });
    const existingRoute = { ...sampleRoute, id: 'r-keep', name: '既存コース' } as SavedRoute;
    saveRoutes([existingRoute]);
    const trip: TripState = { savedRouteId: 'r-keep', startedAt: '2026-08-30T00:00:00.000Z', progress: {} };
    saveTrip(trip);
    const r = parseBackup(backupText());
    if (!r.ok) throw new Error('parse失敗');
    const applied = applyBackup(r.data, 'merge');
    expect(applied.visits['mne-99999']?.state).toBe('wishlist'); // 既存は残る
    expect(applied.visits['mne-00001']?.state).toBe('visited'); // バックアップ優先
    expect(loadRoutes().map((x) => x.id).sort()).toEqual(['r-1', 'r-keep']);
    expect(loadTrip()).toEqual(trip); // バックアップのtripがnullなら既存維持
  });

  it('復元は地図設定キーにも反映される', () => {
    const r = parseBackup(backupText());
    if (!r.ok) throw new Error('parse失敗');
    applyBackup(r.data, 'overwrite');
    expect(localStorage.getItem('tohoku-me:map-settings:v1')).toContain('cluster');
    expect(localStorage.getItem(KEYS.visits)).toContain('mne-00001');
  });
});

describe('地図から選ぶ下書き（schemaVersion 2）との互換性', () => {
  it('旧schemaVersion 1（下書きフィールドなし）は今も復元でき、下書きはnullになる', () => {
    const r = parseBackup(
      JSON.stringify({ schemaVersion: 1, visits: sampleVisits, routes: [], trip: null }),
    );
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.manualDraft).toBeNull();
  });

  it('書き出し→パースで下書きも往復する', () => {
    saveRouteDraft({ ...DEFAULT_ROUTE_DRAFT, selectedIds: ['mne-00001', 'mne-00002'], inProgress: true });
    const b = buildBackup();
    expect(b.schemaVersion).toBe(2);
    const r = parseBackup(JSON.stringify(b));
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.manualDraft?.selectedIds).toEqual(['mne-00001', 'mne-00002']);
  });

  it('壊れたmanualDraftはバックアップ全体を拒否せず、下書きなし扱いにする', () => {
    const r = parseBackup(
      JSON.stringify({
        schemaVersion: 2,
        visits: sampleVisits,
        routes: [],
        trip: null,
        manualDraft: { selectedIds: 'not-an-array' },
      }),
    );
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.data.manualDraft).toBeNull();
      expect(r.data.visits).toEqual(sampleVisits); // 他フィールドは正常に読める
    }
  });

  it('上書き復元: バックアップに下書きが無ければ既存の下書きも消える', () => {
    saveRouteDraft({ ...DEFAULT_ROUTE_DRAFT, selectedIds: ['old'], inProgress: true });
    const r = parseBackup(JSON.stringify({ schemaVersion: 1, visits: {}, routes: [], trip: null }));
    if (!r.ok) throw new Error('parse失敗');
    applyBackup(r.data, 'overwrite');
    expect(loadRouteDraft()).toBeNull();
  });

  it('統合復元: バックアップに下書きが無ければ既存の下書きを残す', () => {
    saveRouteDraft({ ...DEFAULT_ROUTE_DRAFT, selectedIds: ['kept'], inProgress: true });
    const r = parseBackup(JSON.stringify({ schemaVersion: 1, visits: {}, routes: [], trip: null }));
    if (!r.ok) throw new Error('parse失敗');
    applyBackup(r.data, 'merge');
    expect(loadRouteDraft()?.selectedIds).toEqual(['kept']);
  });

  it('復元後、選択途中のルートを再開できる（下書きがそのまま読める）', () => {
    saveRouteDraft({ ...DEFAULT_ROUTE_DRAFT, selectedIds: ['a', 'b', 'c'], inProgress: true, orderMode: 'optimized' });
    const b = buildBackup();
    const r = parseBackup(JSON.stringify(b));
    if (!r.ok) throw new Error('parse失敗');
    const applied = applyBackup(r.data, 'overwrite');
    expect(applied.manualDraft?.selectedIds).toEqual(['a', 'b', 'c']);
    expect(loadRouteDraft()?.selectedIds).toEqual(['a', 'b', 'c']);
  });
});
